package server;

import gui.WebServer;

/**
 * 
 * @author Chandan R. Rupakheti (rupakhcr@clarkson.edu)
 */
public class StartServerMain {
	public static void main(String[] args){
		new WebServer().startServer();
	}
}